Simple RESTful API with Django
==============================

This is the source code for howCode's simple RESTful API with Django.

You can watch the video that accompanies this source code here: https://youtu.be/BSHRftLtPEg
