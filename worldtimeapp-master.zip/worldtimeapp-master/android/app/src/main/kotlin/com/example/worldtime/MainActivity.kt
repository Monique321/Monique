package com.example.worldtime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
